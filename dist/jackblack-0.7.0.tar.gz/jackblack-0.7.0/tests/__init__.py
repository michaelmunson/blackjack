# Empty init file for tests package 
import escprint